# Rebuild Browser MP3

Requires Node.js >=22.12.
From this source directory:

```sh
npm ci
npm run build
```

The resulting dist/standalone/browser-mp3.js replaces the distributed file.
To change the encoder, extract ../third_party/lamejs/source.tar.gz, edit and
build it using its package.json/pnpm-lock.yaml, then install that local package
in this source directory and rerun npm run build. No signing key is needed.
The encoder has not been modified; it retains its LGPL-3.0 license.
The original wrapper and build scripts are MIT licensed.

This source snapshot includes the build inputs. Full tests and application sources:
https://github.com/cityedge/codex_work_01

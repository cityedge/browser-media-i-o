// Import only the library's public API; the app owns subtitle rendering and layout.
export { decodeAudio, getCapabilities, renderMp4 } from 'browser-media-io';
export { enableAacFallback } from 'browser-media-io/aac';

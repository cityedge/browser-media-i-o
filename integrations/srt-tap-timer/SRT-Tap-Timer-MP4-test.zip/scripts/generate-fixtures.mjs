import { mkdirSync, writeFileSync, readFileSync } from 'node:fs';
import { execFileSync } from 'node:child_process';
import { fileURLToPath } from 'node:url';
import path from 'node:path';

export const fixtureDir = fileURLToPath(new URL('../tests/fixtures/', import.meta.url));
export const truth = { sampleRate: 48000, samples: 480000, seconds: 10, fps: 30, frames: 300,
  pulses: [[1, 4, 8], [2, 5, 9]], captions: [[.5, 1], [1, 1.5], [4, 4.5], [8, 8.25]] };
export function ffmpeg(args) {
  return execFileSync(process.env.FFMPEG_PATH || 'ffmpeg', ['-hide_banner', '-loglevel', 'error', '-y', ...args],
    { timeout: 60_000, maxBuffer: 32 * 1024 * 1024 });
}
export function generateFixtures() {
  mkdirSync(fixtureDir, { recursive: true });
  const pcm = Buffer.alloc(truth.samples * 2 * 4);
  for (let i = 0; i < truth.samples; i++) for (let c = 0; c < 2; c++) {
    const t = i / truth.sampleRate;
    const start = truth.pulses[c].find(start => start <= t && t < start + .1);
    const envelope = start === undefined ? 0 : Math.min(1, (t - start) / .005, (start + .1 - t) / .005);
    pcm.writeFloatLE(.7 * Math.sin(2 * Math.PI * (c ? 600 : 1000) * t) * envelope, (i * 2 + c) * 4);
  }
  const raw = path.join(fixtureDir, 'audio.f32'); writeFileSync(raw, pcm);
  const wav = path.join(fixtureDir, 'reference.wav');
  ffmpeg(['-f', 'f32le', '-ar', '48000', '-ac', '2', '-i', raw, '-c:a', 'pcm_s16le', wav]);
  const mp3 = path.join(fixtureDir, 'reference.mp3');
  ffmpeg(['-i', wav, '-c:a', 'libmp3lame', '-q:a', '2', '-write_xing', '1', mp3]);
  const brokenHeader = readFileSync(mp3);
  const at = brokenHeader.indexOf(Buffer.from('Xing'));
  if (at < 0 || !(brokenHeader.readUInt32BE(at + 4) & 1)) throw new Error('MP3 fixture must contain a Xing frame count');
  brokenHeader.writeUInt32BE(Math.floor(brokenHeader.readUInt32BE(at + 8) / 2), at + 8);
  writeFileSync(path.join(fixtureDir, 'wrong-duration.mp3'), brokenHeader);
  ffmpeg(['-f', 'lavfi', '-i', 'color=c=0x213044:s=320x180:d=0.1', '-frames:v', '1', '-threads', '1', path.join(fixtureDir, 'image.png')]);
  writeFileSync(path.join(fixtureDir, 'captions.srt'), '1\n00:00:00,500 --> 00:00:01,000\nONE\n\n2\n00:00:01,000 --> 00:00:01,500\nTWO\n\n3\n00:00:04,000 --> 00:00:04,500\nTHREE\n\n4\n00:00:08,000 --> 00:00:08,250\nFOUR\n');
}
if (process.argv[1] && path.resolve(process.argv[1]) === fileURLToPath(import.meta.url)) generateFixtures();

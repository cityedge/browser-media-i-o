import { build } from 'esbuild';
import { copyFile } from 'node:fs/promises';

await build({
  entryPoints: ['scripts/media-entry.js'],
  outfile: 'vendor/browser-media-io.js',
  bundle: true,
  format: 'iife',
  globalName: 'BrowserMediaIO',
  platform: 'browser',
  target: 'es2022',
  minify: true,
  legalComments: 'linked',
  banner: { js: '/* Browser Media I/O 0.1.0. Rebuild: npm ci && npm run build. See vendor/THIRD_PARTY_NOTICES.md. */' },
});
await copyFile('node_modules/browser-media-io/LICENSE.md', 'vendor/browser-media-io.LICENSE.txt');
await copyFile('node_modules/mediabunny/LICENSE', 'vendor/MPL-2.0.txt');

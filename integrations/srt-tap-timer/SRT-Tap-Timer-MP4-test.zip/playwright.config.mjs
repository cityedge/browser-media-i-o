import { chromium, defineConfig } from '@playwright/test';
import { existsSync } from 'node:fs';

const executablePath = process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH ||
  (!existsSync(chromium.executablePath()) && existsSync('/usr/bin/chromium') ? '/usr/bin/chromium' : undefined);
if (executablePath) console.log(`[SRT tests] Browser: ${executablePath}`);
export default defineConfig({
  testDir: './tests', testMatch: '**/*.spec.mjs', globalSetup: './tests/setup.mjs',
  workers: 1, retries: 0, timeout: 90_000, expect: { timeout: 10_000 }, forbidOnly: !!process.env.CI,
  reporter: [['list'], ['html', { open: 'never' }], ['json', { outputFile: 'test-results/results.json' }]],
  use: { baseURL: 'http://127.0.0.1:4180', browserName: 'chromium', locale: 'ja-JP',
    viewport: { width: 1440, height: 1000 }, launchOptions: { executablePath }, trace: 'retain-on-failure', screenshot: 'only-on-failure' },
  webServer: { command: 'python3 -m http.server 4180 --bind 127.0.0.1', url: 'http://127.0.0.1:4180', reuseExistingServer: false, timeout: 30_000 },
});

import assert from 'node:assert/strict';
import { execFileSync } from 'node:child_process';
import path from 'node:path';
import { ffmpeg, truth, fixtureDir } from '../scripts/generate-fixtures.mjs';

export function inspect(file) {
  return JSON.parse(execFileSync(process.env.FFPROBE_PATH || 'ffprobe', ['-v', 'error', '-count_frames',
    '-show_streams', '-show_format', '-show_frames', '-show_entries', 'frame=media_type,best_effort_timestamp_time',
    '-of', 'json', file], { encoding: 'utf8', timeout: 60_000, maxBuffer: 16 * 1024 * 1024 }));
}
function audioPulses(pcm) {
  const samples = pcm.length / 8, pulses = [];
  for (let c = 0; c < 2; c++) {
    const starts = []; let previous = false;
    for (let i = 0; i < samples; i += 240) {
      const end = Math.min(samples, i + 240); let sum = 0;
      for (let j = i; j < end; j++) sum += pcm.readFloatLE((j * 2 + c) * 4) ** 2;
      const active = Math.sqrt(sum / (end - i)) > .1;
      if (active && !previous) starts.push(i / 48000);
      previous = active;
    }
    pulses.push(starts);
  }
  return pulses;
}
export function verifyOutput(file, portrait = false, source = path.join(fixtureDir, 'reference.wav')) {
  const info = inspect(file), video = info.streams.find(s => s.codec_type === 'video'), audio = info.streams.find(s => s.codec_type === 'audio');
  assert.equal(video.codec_name, 'h264'); assert.equal(audio.codec_name, 'aac');
  assert.equal(video.width, portrait ? 720 : 1280); assert.equal(video.height, portrait ? 1280 : 720);
  assert.equal(Number(video.nb_read_frames), truth.frames); assert.equal(video.avg_frame_rate, '30/1');
  assert.equal(Number(audio.sample_rate), 48000); assert.equal(audio.channels, 2);
  const timestamps = info.frames.filter(f => f.media_type === 'video');
  for (let i = 0; i < truth.frames; i++) assert.ok(Math.abs(Number(timestamps[i].best_effort_timestamp_time) - i / 30) <= .000002);
  const width = portrait ? 180 : 320, height = portrait ? 320 : 180;
  const frames = ffmpeg(['-i', file, '-map', '0:v:0', '-vf', `scale=${width}:${height}`, '-fps_mode', 'passthrough', '-pix_fmt', 'gray', '-f', 'rawvideo', 'pipe:1']);
  assert.equal(frames.length, width * height * truth.frames);
  let captionFrames = 0;
  for (let n = 0; n < truth.frames; n++) {
    const region = frames.subarray((n * height + Math.floor(height * .65)) * width, (n + 1) * height * width);
    let white = 0;
    for (const pixel of region) if (pixel > 210) white++;
    const expected = truth.captions.some(([start, end]) => start <= n / 30 && n / 30 < end);
    assert.equal(white > 5, expected, `Subtitle presence at frame ${n} (${n / 30}s), bright pixels=${white}`);
    if (portrait) {
      // The portrait test zooms the dark image to cover and enables the translucent subtitle band.
      const at = n * width * height + Math.floor(height * .84) * width;
      const outside = frames[at + 2], inside = frames[at + Math.floor(width * .075)];
      assert.ok(outside > 25, `Zoomed image must reach the bottom of portrait frame ${n}`);
      assert.equal(inside < outside * .8, expected, `Subtitle band at frame ${n}`);
    }
    if (expected) captionFrames++;
  }
  const pcm = ffmpeg(['-i', file, '-map', '0:a:0', '-ar', '48000', '-ac', '2', '-f', 'f32le', 'pipe:1']);
  const samples = pcm.length / 8;
  assert.ok(Math.abs(samples - truth.samples) <= 2400, `Decoded samples: ${samples}`);
  const sourcePcm = ffmpeg(['-i', source, '-map', '0:a:0', '-ar', '48000', '-ac', '2', '-f', 'f32le', 'pipe:1']);
  assert.equal(sourcePcm.length / 8, truth.samples);
  const pulses = audioPulses(pcm), sourcePulses = audioPulses(sourcePcm);
  for (let c = 0; c < 2; c++) {
    assert.equal(pulses[c].length, truth.pulses[c].length);
    assert.equal(sourcePulses[c].length, truth.pulses[c].length);
    for (let i = 0; i < pulses[c].length; i++) {
      // Validate fixture distortion independently, then require tighter export fidelity.
      assert.ok(Math.abs(sourcePulses[c][i] - truth.pulses[c][i]) <= .025 + 1e-9);
      assert.ok(Math.abs(pulses[c][i] - sourcePulses[c][i]) <= .005 + 1e-9, `Audio pulse ${c}/${i}: ${pulses[c][i]}`);
    }
  }
  return { videoFrames: truth.frames, captionFrames, decodedAudioSamples: samples, pulses, sourcePulses, width: video.width, height: video.height };
}

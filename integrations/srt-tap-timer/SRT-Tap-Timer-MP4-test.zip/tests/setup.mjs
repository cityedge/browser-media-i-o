import { generateFixtures } from '../scripts/generate-fixtures.mjs';
export default function setup() { generateFixtures(); }

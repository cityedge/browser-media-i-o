import { test, expect } from '@playwright/test';
import { readFile } from 'node:fs/promises';
import path from 'node:path';
import { fixtureDir } from '../scripts/generate-fixtures.mjs';
import { inspect, verifyOutput } from './verify-output.mjs';

const fixture = name => path.join(fixtureDir, name);
const localPage = new URL('../index.html', import.meta.url).href;
async function materials(page, source = 'wrong-duration.mp3') {
  await page.locator('#lyricsFile').setInputFiles(fixture('captions.srt'));
  await expect(page.locator('#linesBody tr')).toHaveCount(4);
  await page.locator('#audioFile').setInputFiles(fixture(source));
  await page.locator('#previewBtn').click();
  await expect(page.locator('#sttvVideoExportModal')).toHaveClass(/show/);
  await page.locator('#sttvImageFile').setInputFiles(fixture('image.png'));
  await expect(page.locator('#sttvRecordButton')).toBeEnabled();
}
async function render(page, outputPath) {
  await page.locator('#sttvRecordButton').click();
  await expect(page.locator('#sttvRecordStatus')).toContainText('作成完了', { timeout: 60_000 });
  const pending = page.waitForEvent('download');
  await page.locator('#sttvDownloadLink').click();
  const download = await pending;
  expect(download.suggestedFilename()).toMatch(/_subtitled\.mp4$/);
  await download.saveAs(outputPath);
}
test.beforeEach(async ({ page }) => {
  page.on('dialog', dialog => dialog.accept());
  // A successful export must not need either capture API.
  await page.addInitScript(() => {
    window.MediaRecorder = undefined;
    HTMLCanvasElement.prototype.captureStream = () => { throw new Error('Screen recording is not allowed'); };
    HTMLMediaElement.prototype.captureStream = () => { throw new Error('Audio capture is not allowed'); };
  });
});

for (const portrait of [false, true]) {
  test(`${portrait ? (process.env.TEST_LOCAL_HTML === '1' ? 'local HTML portrait' : 'offline portrait') : 'HTTP landscape'} renders 300 captioned frames with AAC despite a false MP3 header`, async ({ page, context, browser }, testInfo) => {
    const failures = [], remoteRequests = [];
    page.on('pageerror', error => failures.push(error.message));
    page.on('request', request => { if (/^https?:/.test(request.url())) remoteRequests.push(request.url()); });
    await page.goto(portrait && process.env.TEST_LOCAL_HTML === '1' ? localPage : '/');
    if (portrait) { await context.setOffline(true); remoteRequests.length = 0; }
    await materials(page);
    if (portrait) {
      await page.locator('#sttvShortVideo').check();
      await page.locator('#sttvUseBand').check();
      await page.locator('#sttvFontSize').fill('60');
      await page.locator('#sttvImageFit').fill('100');
    }
    await expect(page.locator('#sttvVideoInfo')).toContainText(portrait ? '720×1280' : '1280×720');
    // Deterministic frames must be independent of preview playback and display refresh.
    await page.evaluate(() => {
      window.requestAnimationFrame = () => 0;
      HTMLMediaElement.prototype.play = () => Promise.reject(new Error('Playback is not allowed during export'));
    });
    const output = testInfo.outputPath('subtitled.mp4');
    await render(page, output);
    await expect(page.locator('#sttvFileStatus')).toContainText('10.000 s / 480,000 samples');
    const verified = verifyOutput(output, portrait, fixture('wrong-duration.mp3'));
    const inputHeader = Number(inspect(fixture('wrong-duration.mp3')).format.duration);
    expect(inputHeader).toBeLessThan(6);
    await testInfo.attach('verification.json', { body: JSON.stringify({ browser: browser.version(), inputHeader, ...verified }), contentType: 'application/json' });
    await page.locator('#sttvPreviewAudio').evaluate(audio => { audio.currentTime = .75; audio.dispatchEvent(new Event('seeked')); });
    await page.screenshot({ path: testInfo.outputPath('completed.png'), fullPage: true });
    expect(failures).toEqual([]);
    if (portrait) expect(remoteRequests).toEqual([]);
    // Changes must not leave a stale MP4 available for download.
    await page.locator('#sttvFontSize').fill('48');
    await expect(page.locator('#sttvDownloadLink')).toBeHidden();
    await expect(page.locator('#sttvDownloadLink')).not.toHaveAttribute('href');
  });
}

test('cancel during export unlocks settings and a retry creates a valid MP4', async ({ page }, testInfo) => {
  await page.goto('/'); await materials(page, 'reference.wav');
  await page.locator('#sttvRecordButton').click();
  await expect(page.locator('#sttvRecordStatus')).toContainText('frames');
  await expect(page.locator('#sttvShortVideo')).toBeDisabled();
  await expect(page.locator('#sttvImageFile')).toBeDisabled();
  await page.locator('#sttvCancelButton').click();
  await expect(page.locator('#sttvRecordStatus')).toHaveText('中止しました。');
  await expect(page.locator('#sttvDownloadLink')).toBeHidden();
  await expect(page.locator('#sttvRecordButton')).toBeEnabled();
  await expect(page.locator('#sttvShortVideo')).toBeEnabled();
  const output = testInfo.outputPath('retry.mp4'); await render(page, output);
  verifyOutput(output);
});

test('invalid audio reports an error and allows replacing the material', async ({ page }, testInfo) => {
  await page.goto('/');
  await page.locator('#lyricsFile').setInputFiles(fixture('captions.srt'));
  await expect(page.locator('#linesBody tr')).toHaveCount(4);
  await page.locator('#audioFile').setInputFiles({ name: 'broken.mp3', mimeType: 'audio/mpeg', buffer: Buffer.from('not audio') });
  await page.locator('#previewBtn').click();
  await page.locator('#sttvImageFile').setInputFiles(fixture('image.png'));
  await page.locator('#sttvRecordButton').click();
  await expect(page.locator('#sttvRecordStatus')).toContainText('エラー');
  await expect(page.locator('#sttvCancelButton')).toBeDisabled();
  await expect(page.locator('#sttvRecordButton')).toBeEnabled();
  await page.locator('#sttvVideoExportCloseX').click();
  await page.locator('#audioFile').setInputFiles(fixture('reference.wav'));
  await page.locator('#previewBtn').click();
  const output = testInfo.outputPath('replaced.mp4'); await render(page, output);
  verifyOutput(output);
});

test('SRT and project saves keep subtitle timing and portrait styling settings', async ({ page }) => {
  await page.goto('/'); await materials(page);
  await page.locator('#sttvShortVideo').check();
  await page.locator('#sttvUseBand').check();
  await page.locator('#sttvFontSize').fill('60');
  await page.locator('#sttvVideoExportCloseX').click();
  const srtPending = page.waitForEvent('download'); await page.locator('#exportBtn').click();
  const srt = await readFile(await (await srtPending).path(), 'utf8');
  expect(srt).toContain('00:00:00,500 --> 00:00:01,000');
  expect(srt).toContain('00:00:08,000 --> 00:00:08,250');
  const projectPending = page.waitForEvent('download'); await page.locator('#saveProjectBtn').click();
  const projectPath = await (await projectPending).path();
  const project = JSON.parse(await readFile(projectPath, 'utf8'));
  expect(project.videoSettings).toMatchObject({ shortVideo: true, useBand: true, fontSize: 60 });
  await page.locator('#projectFile').setInputFiles(projectPath);
  await expect(page.locator('#linesBody tr')).toHaveCount(4);
  await page.locator('#audioFile').setInputFiles(fixture('reference.wav'));
  await page.locator('#previewBtn').click();
  await expect(page.locator('#sttvShortVideo')).toBeChecked();
  await expect(page.locator('#sttvUseBand')).toBeChecked();
  await expect(page.locator('#sttvFontSize')).toHaveValue('60');
  await expect(page.locator('#sttvRecordButton')).toBeDisabled(); // Image files are intentionally not stored in projects.
});

test('missing codec support is explicit and does not break the SRT editor', async ({ page }) => {
  await page.goto('/'); await materials(page);
  await page.evaluate(() => { window.VideoEncoder = undefined; });
  await page.locator('#sttvRecordButton').click();
  await expect(page.locator('#sttvRecordStatus')).toContainText('Chrome');
  await expect(page.locator('#sttvDownloadLink')).toBeHidden();
  await page.locator('#sttvVideoExportCloseX').click();
  await page.locator('#languageSelect').selectOption('en');
  await expect(page.locator('#previewBtn')).toHaveText('Preview / Video Export');
});
